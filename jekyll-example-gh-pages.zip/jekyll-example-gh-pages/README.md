# Example Jekyll site

You're looking at a simple Jekyll site built to show folks how to use Sass with Jekyll. It's open sourced under the MIT license and can be download from [the GitHub project](https://github.com/mdo/jekyll-example).

### Usage

Read the [Using Sass with Jekyll](http://markdotto.com/2014/09/25/sass-and-jekyll/) post.

### Support

**No support is provided with this project.** It is solely meant as a one-time download to accompany the aforementioned blog post.

### License

Released under MIT by @mdo.
